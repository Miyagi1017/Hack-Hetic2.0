---
name: Editorial Voyage
colors:
  surface: '#FFFFFF'
  surface-dim: '#dadad8'
  surface-bright: '#f9f9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f2'
  surface-container: '#eeeeec'
  surface-container-high: '#e8e8e6'
  surface-container-highest: '#e2e3e1'
  on-surface: '#1a1c1b'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e3e2e2'
  on-secondary-container: '#646464'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c1b1a'
  on-tertiary-container: '#868382'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e3e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e6e2df'
  tertiary-fixed-dim: '#cac6c4'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#f9f9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e1'
  border-subtle: '#E8E8E6'
  semantic-success: '#2E7D32'
  semantic-warning: '#E65100'
  semantic-error: '#C62828'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies the quiet luxury of high-end travel journalism, merging the tactile grace of an archival monograph with the effortless frictionlessness of a modern editorial workspace. Built for discerning travelers, curatorial trip planners, and bespoke concierge experiences, the interface emphasizes spacious serenity, deliberate typography, and high-contrast precision.

The aesthetic fuses **Editorial Minimalism** with **Warm Architectural Precision**:
- **Uncluttered Canvas:** Generous negative space and subtle tonal shifts evoke premium heavy-stock paper.
- **Graphic Contrast:** Utilitarian jet-black accents and razor-sharp typographic hierarchy anchor fluid photography and complex itinerary layouts.
- **Intentional Restraint:** Color is deployed exclusively for semantic orientation and itinerary feasibility alerts; content and destination imagery provide the chromatic richness.

## Colors

The palette is anchored by a warm architectural gray canvas (`#F5F5F3`) and pure, elevated card surfaces (`#FFFFFF`). Contrast is strictly commanded by the primary near-black (`#171717`), eliminating superfluous decorative hues to elevate user-generated travel photography and cartographic overlays.

- **Canvas & Surfaces:** `#F5F5F3` acts as the unifying page foundation, creating subtle atmospheric separation when pure white `#FFFFFF` cards, drawers, and modal panels sit upon it.
- **Borders & Dividers:** Crisp structural delineations utilize `#E8E8E6` at 1px thickness without heavy shadows.
- **Text & Hierarchy:** Headers, primary CTA states, and prominent numbers run in `#171717`. Secondary metadata, durations, and supporting subtitles utilize `#858585`.
- **Semantic Indicators:** Restrained jewel tones signal itinerary health without visual noise: `#2E7D32` for verified bookings and feasible transit gaps, `#E65100` for tight schedule connections, and `#C62828` for direct routing conflicts or visa constraints.

## Typography

Typography establishes an intentional cadence between literary romance and operational efficiency:

- **Editorial Serif (`Newsreader`):** Used exclusively for destination names, journal entries, storytelling headers, and daily itinerary overviews. Its subtle optical sizing and graceful italics invoke high-production print editions.
- **Modern Geometric Sans (`Plus Jakarta Sans`):** Powers application mechanics, navigation bars, interactive form fields, timeline timecodes, distance calculations, and tag badges.
- **Letter Spacing & Casing:** Section super-titles, status badges, and airport/station codes run in `label-sm` with slight tracking (`0.05em`) and uppercase styling. Editorial headers remain standard case with gentle tightening (`-0.01em` to `-0.02em`).

## Layout & Spacing

The layout is structured around an asymmetric 12-column responsive grid engineered for multi-pane workflows (e.g., synchronized itinerary feed beside an interactive map).

- **Desktop (1280px+):** Max page container width of 1440px with `margin` (3rem) and `gutter` (1.5rem). The standard trip planning view divides cleanly into a 5-column scrolling timeline itinerary and a 7-column fixed map/visual canvas.
- **Tablet (768px - 1279px):** An 8-column layout. Timelines and visual overviews switch to a stacked or tab-toggled presentation with 2rem side margins.
- **Mobile (< 768px):** Single-column stream with `margin-mobile` (1.25rem) and bottom-anchored floating sheet navigation.
- **Vertical Spacing Rhythm:** Component interiors strictly scale via `space-sm` (8px), `space-md` (16px), and `space-lg` (24px). Section dividers and day-by-day itinerary groups leverage `space-xl` (40px) to guarantee breathing room.

## Elevation & Depth

Visual hierarchy relies on crisp surface transitions, tonal containment, and ultra-soft ambient shadowing rather than dramatic elevation tiers:

- **Layer 0 (Canvas):** Base background `#F5F5F3`. Completely flat.
- **Layer 1 (Cards & Sidebars):** Pure white `#FFFFFF` with a 1px hairline border (`#E8E8E6`) and an ambient, ultra-diffused shadow: `box-shadow: 0 4px 20px -2px rgba(23, 23, 23, 0.03)`.
- **Layer 2 (Floating Floating Map Overlays & Popovers):** Pure white `#FFFFFF` bounded by `#E8E8E6` and an elevated drop shadow: `box-shadow: 0 12px 32px -4px rgba(23, 23, 23, 0.08)`.
- **Layer 3 (Modals & Full Sheets):** Backdrop utilizes a muted blur overlay: `rgba(245, 245, 243, 0.8)` with `backdrop-filter: blur(8px)`.

## Shapes

The interface balances generous soft-radius containers with sharp structural precision:

- **Cards & Content Blocks:** Built with custom radii spanning `18px` to `24px` (`rounded-xl`), creating an inviting, tactile card deck aesthetic.
- **Buttons, Badges & Chips:** Enforced full pill morphology (`border-radius: 9999px`) to create an unmistakable functional distinction between passive containers and interactive triggers.
- **Form Inputs & Search Surfaces:** Soft curved frames with `border-radius: 12px` to seamlessly match input groups.

## Components

### Buttons
- **Primary:** Full pill silhouette (`rounded-full`), `#171717` solid fill, white text `#FFFFFF`. Minimum tap height 44px, horizontal padding 24px (`space-lg`). No box shadow; hover state scales slightly (`scale(1.01)`) with background transitioning to `#2B2B2B`.
- **Secondary:** Full pill silhouette, pure white background `#FFFFFF`, 1px solid border `#E8E8E6`, primary text `#171717`. Hover triggers `#F5F5F3` fill and border color `#171717`.
- **Tertiary / Ghost:** Text-only in `#171717` or `#858585` with an underline transition on hover.

### Chips & Badges
- **Pill Badges (Metadata & Distance):** Compact 28px height, `label-sm` typography, padding 4px 12px. Unselected state: `#FFFFFF` fill with 1px `#E8E8E6` border and `#858585` text. Selected state: solid `#171717` fill with `#FFFFFF` text.
- **Status Chips:** Transit badges (e.g., "3h 45m flight") feature subtle icons paired with `#171717` typography against a `#F5F5F3` pill background.

### Cards
- **Itinerary Day Cards:** Pure white background, `20px` border-radius, 1px border `#E8E8E6`. Internal padding `space-lg` (24px). Accommodates nested thumbnail carousels, time stamps, and location tags.
- **Interactive Map Previews:** Cards featuring aspect-ratio-bound hero photography pinned with pill-shaped coordinate markers.

### Inputs & Search
- **Editorial Search Field:** Pill or `14px` rounded rectangular container with `#FFFFFF` fill, 1px `#E8E8E6` border, and subtle text placeholder in `#858585`. Focus ring uses a clean 1.5px outline in `#171717` without chromatic glow.

### Checkboxes & Radios
- **Selection Controls:** Minimalist geometry. Checkboxes feature `4px` corner radii; radio inputs are perfect circles. Unselected: 1.5px border `#E8E8E6`. Checked: solid `#171717` background with a crisp white tick or inner dot.

### Timeline & Itinerary Feasibility Alerts
- **Timeline Connector:** Continuous 1.5px vertical line in `#E8E8E6` punctuated by 8px circular nodes (solid `#171717` for completed/confirmed, hollow for tentative stops).
- **Conflict Warning Banner:** Pill-shaped inline pill or slim alert card with a 1px border in `#E65100` (amber) or `#C62828` (red), paired with a pale tinted background (`rgba(230, 81, 0, 0.06)`) and high-legibility bold warning copy.